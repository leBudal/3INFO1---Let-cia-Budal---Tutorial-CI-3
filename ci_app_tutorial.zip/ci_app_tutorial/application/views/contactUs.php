<div class="container">
<div class="row clearfix">
<div class="col-md-12 column">
<div class="row clearfix">
<div class="col-md-6 column">
<form role="form">

<div class="form-group">
<label for="exampleInputEmail1">Name</label><input class="form-control" id="exampleInputEmail1" type="text" />
</div>

<div class="form-group">
<label for="exampleInputEmail1">Email address</label><input class="form-control" id="exampleInputEmail1" type="email"/>
</div>

<div class="form-group">
<label for="exampleInputEmail1">Comment</label>
<textarea class="form-control">
</textarea>
</div>

<button type="submit" class="btn btn-
default">Submit</button>
</form>

</div>
<div class="col-md-6 column">
<h3>
Contact us
</h3> <address> <strong>Twitter, Inc.</strong><br /> 795 Folsom Ave,
Suite 600<br /> San Francisco, CA 94107<br /> <abbr title="Phone">P:</abbr> (123) 456-7890</address>
</div>
</div>
</div>
</div>
</div>
</body>
</html>